export const theme = {
  name: process.env.NEXT_PUBLIC_THEME_NAME || 'Agence AKA',
  colors: {
    primary: 'var(--color-primary)',
    bg: 'var(--color-bg)',
    text: 'var(--color-text)',
    surface: 'var(--color-surface)'
  }
};
