import { theme } from "../theme";
export default function Home() {
  return <div>
    <h1>Bienvenue sur {theme.name} 👋</h1>
    <p>Votre intranet est prêt.</p>
    <ul>
      <li>🔔 <a href="/feed">Fil d'annonces</a></li>
      <li>💬 <a href="/teams">Équipes & chat</a></li>
      <li>🔎 <a href="/search">Recherche</a></li>
    </ul>
  </div>
}
