import "./globals.css";
import { ReactNode } from "react";
import { NextAuthProvider } from "../components/NextAuthProvider";
import { theme } from "../theme";

export const metadata = { title: theme.name };

export default function RootLayout({ children }: { children: React.ReactNode}) {
  return (
    <html lang="fr">
      <body>
        <NextAuthProvider>
          <div style={{ maxWidth: 1000, margin: "0 auto" }}>
            <header style={{ display: "flex", gap: 16, alignItems: "center", padding: "6px 24px" }}>
              <a href="/" style={{ display:'flex', alignItems:'center', gap:12 }}>
                <img src="/logo.svg" alt="Logo" width={28} height={28} />
                <strong>{theme.name}</strong>
              </a>
              <a href="/feed">Fil d'annonces</a>
              <a href="/teams">Équipes</a>
              <a href="/search">Recherche</a>
              <div style={{ marginLeft: "auto" }}><a href="/api/auth/signout">Se déconnecter</a></div>
            </header>
            <main style={{ padding: 24 }}>{children}</main>
          </div>
        </NextAuthProvider>
      </body>
    </html>
  );
}
