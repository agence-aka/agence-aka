import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { PrismaService } from '../services/prisma.service';
@Controller('teams')
export class TeamsController {
  constructor(private prisma: PrismaService) {}
  @Get() async list() { return this.prisma.team.findMany({ include: { members: true } }); }
  @Post() async create(@Body() dto: { name: string, description?: string }) {
    return this.prisma.team.create({ data: { name: dto.name, description: dto.description } });
  }
  @Get(':id') async get(@Param('id') id: string) {
    return this.prisma.team.findUnique({ where: { id }, include: { members: true } });
  }
}
