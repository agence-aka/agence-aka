import { Controller, Get, Param } from '@nestjs/common';
import { PrismaService } from '../services/prisma.service';
@Controller('users')
export class UsersController {
  constructor(private prisma: PrismaService) {}
  @Get() async list() { return this.prisma.user.findMany(); }
  @Get(':id') async get(@Param('id') id: string) { return this.prisma.user.findUnique({ where: { id } }); }
}
