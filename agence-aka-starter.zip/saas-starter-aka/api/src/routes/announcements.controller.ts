import { Body, Controller, Get, Post } from '@nestjs/common';
import { PrismaService } from '../services/prisma.service';
import { RealtimeGateway } from '../realtime/gateway';
import { Roles } from '../auth/roles.decorator';
@Controller('announcements')
export class AnnouncementsController {
  constructor(private prisma: PrismaService, private rt: RealtimeGateway) {}
  @Get() async list() {
    return this.prisma.announcement.findMany({ orderBy: { createdAt: 'desc' }, include: { author: true } });
  }
  @Post() @Roles('MANAGER','ADMIN')
  async create(@Body() dto: { authorId: string, title: string, body: string, pinned?: boolean }) {
    const res = await this.prisma.announcement.create({ data: dto });
    this.rt.emitAll('announcement.created', res);
    return res;
  }
}
