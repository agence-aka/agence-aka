import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { PrismaService } from '../services/prisma.service';
import { RealtimeGateway } from '../realtime/gateway';
import { Roles } from '../auth/roles.decorator';
@Controller('teams/:id/messages')
export class MessagesController {
  constructor(private prisma: PrismaService, private rt: RealtimeGateway) {}
  @Get() async list(@Param('id') teamId: string, @Query('cursor') cursor?: string) {
    const take = 20; const where = { teamId };
    if (cursor) return this.prisma.message.findMany({ take, skip: 1, cursor: { id: cursor }, where, orderBy: { createdAt: 'desc' }, include: { author: true } });
    return this.prisma.message.findMany({ take, where, orderBy: { createdAt: 'desc' }, include: { author: true } });
  }
  @Post() @Roles('EMPLOYEE','MANAGER','ADMIN')
  async create(@Param('id') teamId: string, @Body() dto: { authorId: string, body: string }) {
    const msg = await this.prisma.message.create({ data: { teamId, authorId: dto.authorId, body: dto.body } });
    this.rt.emitToTeam(teamId, 'message.created', msg); return msg;
  }
}
