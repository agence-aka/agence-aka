import { Controller, Get, Query } from '@nestjs/common';
import { PrismaService } from '../services/prisma.service';
@Controller('search')
export class SearchController {
  constructor(private prisma: PrismaService) {}
  @Get() async q(@Query('q') q: string) {
    if (!q) return { announcements: [], messages: [] };
    const escaped = q.replace(/'/g, "''");
    const announcements = await this.prisma.$queryRawUnsafe(`
      SELECT id, title, body, "createdAt" FROM "Announcement"
      WHERE search @@ plainto_tsquery('simple', '${escaped}')
      ORDER BY "createdAt" DESC LIMIT 20
    `);
    const messages = await this.prisma.$queryRawUnsafe(`
      SELECT id, body, "createdAt", "teamId", "authorId" FROM "Message"
      WHERE search @@ plainto_tsquery('simple', '${escaped}')
      ORDER BY "createdAt" DESC LIMIT 20
    `);
    return { announcements, messages };
  }
}
