import { Controller, Get, Param, Post, UploadedFile, UseInterceptors, Body } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { PrismaService } from '../services/prisma.service';
import { MinioService } from '../services/minio.service';
import { Roles } from '../auth/roles.decorator';
@Controller()
export class FilesController {
  constructor(private prisma: PrismaService, private minio: MinioService) {}
  @Get('teams/:id/files') async list(@Param('id') teamId: string) {
    return this.prisma.file.findMany({ where: { teamId }, orderBy: { createdAt: 'desc' } });
  }
  @Post('files') @UseInterceptors(FileInterceptor('file')) @Roles('EMPLOYEE','MANAGER','ADMIN')
  async upload(@UploadedFile() file: Express.Multer.File, @Body() body: { teamId?: string, uploaderId?: string }) {
    const key = `${body.teamId || 'general'}/${Date.now()}-${file.originalname}`;
    const url = await this.minio.putObject(key, file.stream, file.size, { 'Content-Type': file.mimetype });
    return this.prisma.file.create({ data: { teamId: body.teamId, uploaderId: body.uploaderId, name: file.originalname, url } });
  }
  @Post('files/presign') @Roles('EMPLOYEE','MANAGER','ADMIN')
  async presign(@Body() body: { filename: string, teamId?: string, contentType?: string }) {
    const key = `${body.teamId || 'general'}/${Date.now()}-${body.filename}`;
    const url = await this.minio.client.presignedPutObject(this.minio.bucket, key, 60*5, { 'Content-Type': body.contentType || 'application/octet-stream' });
    const publicUrl = `${process.env.MINIO_PUBLIC_HOST || 'http://localhost:9000'}/${this.minio.bucket}/${encodeURIComponent(key)}`;
    return { key, uploadUrl: url, publicUrl };
  }
  @Post('files/confirm') @Roles('EMPLOYEE','MANAGER','ADMIN')
  async confirm(@Body() body: { key: string, name: string, teamId?: string, uploaderId?: string, url?: string }) {
    const url = body.url || `${process.env.MINIO_PUBLIC_HOST || 'http://localhost:9000'}/${this.minio.bucket}/${encodeURIComponent(body.key)}`;
    return this.prisma.file.create({ data: { teamId: body.teamId, uploaderId: body.uploaderId, name: body.name, url } });
  }
}
