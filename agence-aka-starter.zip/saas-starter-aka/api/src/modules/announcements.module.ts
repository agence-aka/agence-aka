import { Module } from '@nestjs/common';
import { AnnouncementsController } from '../routes/announcements.controller';
import { PrismaService } from '../services/prisma.service';
@Module({ controllers: [AnnouncementsController], providers: [PrismaService] })
export class AnnouncementsModule {}
