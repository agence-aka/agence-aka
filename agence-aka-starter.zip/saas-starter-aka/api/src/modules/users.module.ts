import { Module } from '@nestjs/common';
import { UsersController } from '../routes/users.controller';
import { PrismaService } from '../services/prisma.service';
@Module({ controllers: [UsersController], providers: [PrismaService] })
export class UsersModule {}
