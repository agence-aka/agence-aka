import { Module } from '@nestjs/common';
import { FilesController } from '../routes/files.controller';
import { PrismaService } from '../services/prisma.service';
import { MinioService } from '../services/minio.service';
@Module({ controllers: [FilesController], providers: [PrismaService, MinioService] })
export class FilesModule {}
