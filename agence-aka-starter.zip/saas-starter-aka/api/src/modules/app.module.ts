import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { HealthController } from '../routes/health.controller';
import { UsersModule } from './users.module';
import { TeamsModule } from './teams.module';
import { AnnouncementsModule } from './announcements.module';
import { MessagesModule } from './messages.module';
import { FilesModule } from './files.module';
import { PrismaService } from '../services/prisma.service';
import { RealtimeGateway } from '../realtime/gateway';
import { RolesGuard } from '../auth/roles.guard';
import { SearchController } from '../routes/search.controller';

@Module({
  imports: [UsersModule, TeamsModule, AnnouncementsModule, MessagesModule, FilesModule],
  controllers: [HealthController, SearchController],
  providers: [PrismaService, RealtimeGateway, { provide: APP_GUARD, useClass: RolesGuard }],
})
export class AppModule {}
