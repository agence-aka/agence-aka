import { Module } from '@nestjs/common';
import { MessagesController } from '../routes/messages.controller';
import { PrismaService } from '../services/prisma.service';
@Module({ controllers: [MessagesController], providers: [PrismaService] })
export class MessagesModule {}
