import { Module } from '@nestjs/common';
import { TeamsController } from '../routes/teams.controller';
import { PrismaService } from '../services/prisma.service';
@Module({ controllers: [TeamsController], providers: [PrismaService] })
export class TeamsModule {}
