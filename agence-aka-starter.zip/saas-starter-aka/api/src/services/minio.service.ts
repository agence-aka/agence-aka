import { Injectable, OnModuleInit } from '@nestjs/common';
import { Client } from 'minio';
@Injectable()
export class MinioService implements OnModuleInit {
  client: Client; bucket: string = process.env.MINIO_BUCKET || 'files';
  constructor() { this.client = new Client({
    endPoint: process.env.MINIO_ENDPOINT || 'minio',
    port: Number(process.env.MINIO_PORT || 9000),
    accessKey: process.env.MINIO_ACCESS_KEY || 'admin',
    secretKey: process.env.MINIO_SECRET_KEY || 'adminadmin',
    useSSL: (process.env.MINIO_USE_SSL || 'false') === 'true'
  }); }
  async onModuleInit() {
    const exists = await this.client.bucketExists(this.bucket).catch(() => false);
    if (!exists) await this.client.makeBucket(this.bucket, 'us-east-1');
  }
  async putObject(name: string, stream: NodeJS.ReadableStream, size?: number, meta: any = {}) {
    await this.client.putObject(this.bucket, name, stream, size, meta);
    const host = process.env.MINIO_PUBLIC_HOST || `http://localhost:${process.env.MINIO_PORT || 9000}`;
    return `${host}/${this.bucket}/${encodeURIComponent(name)}`;
  }
}
