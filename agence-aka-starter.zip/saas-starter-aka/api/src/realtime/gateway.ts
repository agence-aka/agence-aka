import { OnGatewayConnection, OnGatewayDisconnect, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
@WebSocketGateway({ cors: { origin: '*' } })
export class RealtimeGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server!: Server;
  private online = new Map<string, number>();
  handleConnection(client: Socket) {
    const userId = (client.handshake.auth?.userId || client.handshake.query.userId || 'anon') as string;
    client.data.userId = userId;
    const count = this.online.get(userId) || 0;
    this.online.set(userId, count + 1);
    this.server.emit('user.presence', { userId, online: true });
  }
  handleDisconnect(client: Socket) {
    const userId = client.data.userId || 'anon';
    const count = (this.online.get(userId) || 1) - 1;
    if (count <= 0) { this.online.delete(userId); this.server.emit('user.presence', { userId, online: false }); }
    else { this.online.set(userId, count); }
  }
  emitToTeam(teamId: string, event: string, payload: any) { this.server.to(`team:${teamId}`).emit(event, payload); }
  emitAll(event: string, payload: any) { this.server.emit(event, payload); }
  @SubscribeMessage('join.team') onJoin(client: Socket, data: { teamId: string }) {
    client.join(`team:${data.teamId}`); client.emit('joined.team', { teamId: data.teamId });
  }
}
