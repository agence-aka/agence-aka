ALTER TABLE "Announcement" ADD COLUMN IF NOT EXISTS "search" tsvector;
ALTER TABLE "Message" ADD COLUMN IF NOT EXISTS "search" tsvector;
UPDATE "Announcement" SET "search" = to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(body,''));
UPDATE "Message" SET "search" = to_tsvector('simple', coalesce(body,''));
CREATE INDEX IF NOT EXISTS announcement_search_idx ON "Announcement" USING GIN ("search");
CREATE INDEX IF NOT EXISTS message_search_idx ON "Message" USING GIN ("search");
CREATE OR REPLACE FUNCTION announcement_search_tsv() RETURNS trigger AS $$
BEGIN NEW.search := to_tsvector('simple', coalesce(NEW.title,'') || ' ' || coalesce(NEW.body,'')); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE OR REPLACE TRIGGER announcement_search_tsv_trigger BEFORE INSERT OR UPDATE ON "Announcement" FOR EACH ROW EXECUTE PROCEDURE announcement_search_tsv();
CREATE OR REPLACE FUNCTION message_search_tsv() RETURNS trigger AS $$
BEGIN NEW.search := to_tsvector('simple', coalesce(NEW.body,'')); RETURN NEW; END; $$ LANGUAGE plpgsql;
CREATE OR REPLACE TRIGGER message_search_tsv_trigger BEFORE INSERT OR UPDATE ON "Message" FOR EACH ROW EXECUTE PROCEDURE message_search_tsv();
