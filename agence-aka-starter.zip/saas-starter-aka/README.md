# Agence AKA — SaaS Intranet

Stack: Next.js (App Router) + NextAuth (OIDC) + NestJS + Prisma(Postgres) + Redis + S3/MinIO + Socket.IO.

## Démarrage rapide
```bash
docker compose up -d --build
# Web: http://localhost:3000
# API: http://localhost:3001/health
# Keycloak: http://localhost:8080 (admin/admin)
# MinIO: http://localhost:9001 (admin/adminadmin)
```
